VERMA KIRAN STORE — UPDATED FUZZY SEARCH

Files:
- index.html: single-file browser-ready storefront prototype.

Search behavior:
- Uses dynamic typo-tolerant matching (edit distance with adjacent-letter transpositions plus character-bigram similarity), not only a fixed list of example misspellings.
- Searches brand, product name, description, and pack size.
- Handles common product word variations such as Fortune/Fortnue, Ruchi Gol, Mahakos, Abse Gld, Soyabin/Suyabin, oil/tel, and 1L/5L size terms.
- When a query has no close match, it shows the closest available products rather than a blank page.
- A typed search clears the selected brand filter so it doesn't hide matching products.

Tested typo examples against the sample product catalogue:
Fortnue -> Fortune
Fottune -> Fortune
Ruchi Gol -> Ruchi Gold
Mahakos / Maha Kosh -> Mahakosh
Abse Gld -> Abse Gold
Soyabin Tel / Suyabin Tel -> soybean oil products
Mahakosh 5 ltr -> Mahakosh 5 L jar

IMPORTANT LIMITATIONS:
- This is still a static prototype. The current HTML stores product/admin changes in the current browser only. It does not sync changes to every customer.
- To update a hosted website, replace the old hosted index.html with this new index.html and deploy/publish it again.
- Admin PIN in the demo is not secure for a public store.
- Online payment, server-side admin authentication, shared database, image hosting and real order management are not configured.
- Sample product prices and stock must be checked and updated before public launch.


UPI payment added: UPI ID 8305542822@ybl and supplied PhonePe QR are embedded in the cart. This is manual UPI payment only; the website cannot verify payment automatically. Confirm receipt in your UPI/bank app before dispatch.
